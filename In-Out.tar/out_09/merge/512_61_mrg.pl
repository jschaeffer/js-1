#!/usr/bin/perl
#
# Program to automate the Merge activities from source location to desitnation 
# (branch to trunk, branch to branch, etc.)
#
# This program uses the TKCVS branch-trunk tag standard to identify 
# merge points within the graphical display of the version tree.
#
# Author: J. Schaeffer 2 Feb. 04
#			Updated 27 mar. 06
#
# Command execution needs the 'full or incr' argument passed to continue
#  - 'full' indicates the entire set of branch changes since the branch creation should be
#  evaluated and merged.
#  - 'incr' indicates only the changes applied since a previous tag was placed should be evaluated 
#  and merged (tag to be supplied in the variable list in the 'defineVars' routine below
#  
# In the 'defineVars' routing below set the following for variables for full merges:
# -$MODULE_NAME, $BRANCH_NAME (source), $HEAD (dest, ie; HEAD for trunk), MERGE_DATE (ie; _<day><mon><yr>) 
#  For incr merges also set the MERGE_FROM_INCR to the prior merge tag for changes since application

#  Define needed routines for the merge process 

	&defineVars;
#	&makeDirstruct;

# Only one or the other can be used between coHead or upHead depending on 
# whether you already have a workarea checked out under the 'head' location.  
# Use coHead for new checkouts, upHead for existing checkouts.

	&coHead;
#	&upHead;
	&makeMergearea;
	&makeMergereport;
	&makeMergescript;
#	&makeTagscript;
	&cleanUp;


sub defineVars {

# RE Defined variables

#  17625 - 17635 - Merge from br_5_5_1 -> br_5-6_0
#  17507 - 17710 - Merge from br_5-6_0 -> br_5_x
#  17712 - 17792 - Merge from br_5-6_0 -> br_5-x
#  17795 - 17863 - Merge from br_5_6_0 -> br_5_x
#  17865 - 17946 - Merge from br_5_6_0 -> br_5_7_0
#  17957 - 17970 - Merge from br_5-6_0 -> br_5_7_0
#  17947:18045 - Merge from br_5_7_0 -> br_5_x
#  18047 - 18150   - Merge from br_5_7_0 -> br_5_x
#  18152 - 18223 - Merge from br_5-7_0 -> br_5_x
#  18225 - 18299 - Merge from br_5_7_0 -> br_5_x
#  18301 - 18308 - Merge from br_5-7_0 -> br_5_x
#  18312 - 18432 - Merge from br_5_9_0 -> br_5-x
#  18434 - Merge from br_5_9_0 => br_5_x
#  18628 - Problems merging from
#  18680 - 5.10 branch creation from rev 18312

$SVNLOOK_CMD = `which svnlook`;
chomp $SVNLOOK_CMD;

$SVN_CMD = `which svn`;
chomp $SVN_CMD;
$S_REV = "19878";
$E_REV =`$SVNLOOK_CMD youngest /upp/svn/repos`;
$REV_RNG = "$S_REV:$E_REV";
chomp $REV_RNG;

$MODULE_NAME="world";
$BRANCH_NAME="br_5_12_0";
$MERGE_DATE="_22Jul2009";

$HEAD="br_6_1_0";

# END RE Defined variables

# Pre-defined variables
$MERGE_POINT="MergePoint";
$MERGE_REVIEW="MergeReview";
$MERGE_FROM_INCR="MergeReview_28Aug2007";
$MERGE_FROM_TAG="mergefrom_";
$MERGE_TO_TAG="mergeto_";
$LOG_DIR="/tmp";
$CMD_SEQ="no";
$CURDIR=`pwd`;
chomp $CURDIR;
$MW="/merge_work";
$MERGE_WORK="$CURDIR$MW";
$MERGE_RPT="$LOG_DIR/MERGE_RPT_$BRANCH_NAME.txt";
$MERGE_ERR="$LOG_DIR/MERGE_ERR_$BRANCH_NAME.log";
$MERGE_HEAD_LOC="$MERGE_WORK/$MODULE_NAME/$HEAD";
$MERGE_BRANCH_LOC="$MERGE_WORK/$MODULE_NAME/$BRANCH_NAME";
$MERGE_PRG="$MERGE_WORK/$MODULE_NAME/$HEAD/MERGE_EXE_$BRANCH_NAME.sh";
$MERGE_PRG_ERR="$MERGE_WORK/$MODULE_NAME/$HEAD/CVS_ERR_$BRANCH_NAME.log";
$TAGBR_PRG="$MERGE_WORK/$MODULE_NAME/$BRANCH_NAME/TAGBR_EXE_$BRANCH_NAME.sh";
$TAGBR_PRG_ERR="$MERGE_WORK/$MODULE_NAME/$BRANCH_NAME/TAG_ERR_$BRANCH_NAME.log";
$RPT_TITLE="Branch Merge Report - Initial MergePoint Review $MERGE_POINT$HEAD$MERGE_DATE";
	@added = qw();
	@modified = qw();
	@removed = qw();
	@conflicts = qw();
	@mod_list = (@added, @modified, @conflicts);
	@br_tag_list = (@added, @modified, @conflicts);
		# If updated at parent dir. $start = (length($MODULE_NAME)+1);
		# If updated at parent dir. $checkin1 = substr($checkin, $start);	

#  Report names to be placed in the Log directory
$MERGE_RPT="$LOG_DIR/MERGE_RPT_$BRANCH_NAME.txt";
$MERGE_ERR="$LOG_DIR/MERGE_ERR_$BRANCH_NAME.log";
$TMP_OUT="/tmp/tmp.lis";
$TMP_ERR="/tmp/tmp_err.lis";

#  Shell scripts which will actually do the lion's share of the merge, commit and tag effort
$MERGE_PRG="$MERGE_WORK/$MODULE_NAME/$HEAD/MERGE_EXE_$BRANCH_NAME.sh";
$MERGE_PRG_ERR="$MERGE_WORK/$MODULE_NAME/$HEAD/SVN_ERR_$BRANCH_NAME.log";
$TAGBR_PRG="$MERGE_WORK/$MODULE_NAME/$BRANCH_NAME/TAGBR_EXE_$BRANCH_NAME.sh";
$TAGBR_PRG_ERR="$MERGE_WORK/$MODULE_NAME/$BRANCH_NAME/TAG_ERR_$BRANCH_NAME.log";

}


sub makeDirstruct {

open (STDOUT, ">$MERGE_RPT");
open (STDERR, ">$MERGE_ERR");


	print "\# $RPT_TITLE\n";	

	if (chdir("$MERGE_WORK")) {
	        print "Moved to the working directory:  $MERGE_WORK\n";
	} else {
      		chdir("$MERGE_WORK") || mkdir("$MERGE_WORK");
        	print "Created merge workarea at -> $MERGE_WORK\n";
		chdir("$MERGE_WORK");
	}
	mkdir("$MODULE_NAME") || die "Couldn't make the base directory";
        chdir("$MODULE_NAME") || die "Couldn't change to the $MODULE_NAME directory";
	mkdir("./$HEAD") || die "Couldn't make the trunk directory";
        mkdir("./$BRANCH_NAME") || die "Couldn't make the branch directory";
             
$CMD_SEQ="yes";

}


sub coHead {
        if ($CMD_SEQ="no") {
                open (STDOUT, ">>$MERGE_RPT");
                open (STDERR, ">>$MERGE_ERR");
        }

	chdir("$MERGE_HEAD_LOC") || die "Couldn't change to the trunk directory";
	print "1. Merge to workarea checked out from $MODULE_NAME on $HEAD\n";
	if ($HEAD eq 'trunk') {
		print "   cmd used - svn co svn://reproc.sfbay/$MODULE_NAME/trunk $MODULE_NAME\n";
		`$SVN_CMD co svn://reproc.sfbay/$MODULE_NAME/trunk $MODULE_NAME`;
	} else {
		print "   cmd used - svn co svn://reproc.sfbay/$MODULE_NAME/branches/$HEAD $MODULE_NAME\n";
		`$SVN_CMD co svn://reproc.sfbay/$MODULE_NAME/branches/$HEAD $MODULE_NAME`;
	}

#	chdir("$MERGE_BRANCH_LOC") || die "Couldn't change to the $MERGE_BRANCH_LOC directory";
#		print "   cmd used - svn co svn://reproc.sfbay/$MODULE_NAME/branches/$BRANCH_NAME $MODULE_NAME\n";
#		`$SVN_CMD co svn://reproc.sfbay/$MODULE_NAME/branches/$BRANCH_NAME $MODULE_NAME`;

#	chdir("$MODULE_NAME") || die "Couldn't change to the $MODULE_NAME directory";

$CMD_SEQ="yes";

}

sub upHead {
        if ($CMD_SEQ="no") {
                open (STDOUT, ">>$MERGE_RPT");
                open (STDERR, ">>$MERGE_ERR");
        }

        chdir("$MERGE_HEAD_LOC/$MODULE_NAME") || die "Couldn't change to the trunk directory";
        print "2. Merge to workarea checked out from $MODULE_NAME on $HEAD\n";
                print "   cmd used - svn update\n";
                `$SVN_CMD update`;


$CMD_SEQ="yes";

}

sub makeMergearea {
        if ($CMD_SEQ="no") {
               open (STDOUT, ">>$MERGE_RPT");
               open (STDERR, ">>$MERGE_ERR");
        }

        chdir("$MERGE_HEAD_LOC/$MODULE_NAME") || die "Couldn't change to the merge_to workarea for merging";

	print "2. Merge from revisions $S_REV - to - $E_REV on $BRANCH_NAME -> $HEAD\n";
	print "   cmd used - svn merge -r$REV_RNG svn://reproc.sfbay/$MODULE_NAME/branches/$BRANCH_NAME \>$MERGE_WORK/MERGE_OUTPUT.log\n";
	 `$SVN_CMD merge -r$REV_RNG svn://reproc.sfbay/$MODULE_NAME/branches/$BRANCH_NAME >$MERGE_WORK/MERGE_OUTPUT.log`;


$CMD_SEQ="yes";

}

sub makeMergereport {
        if ($CMD_SEQ="no") {
                open (STDOUT, ">>$MERGE_RPT");
                open (STDERR, ">>$MERGE_ERR");
        }

	chdir("$MERGEWORK") || die "Couldn't change to the merge work to report generation";


	@added = qw();
	@modified = qw();
	@removed = qw();
	@conflicts = qw();

	open(infile, "$MERGE_WORK/MERGE_OUTPUT.log") || die "Can't open file: $!";
	
	while(<infile>) {
		if (/^A/) {
			push @added, substr($_, 2); 
		} elsif (/^U/) {
			push @modified, substr($_, 2);
		} elsif (/^D/) {
			push @removed, substr($_, 2);
		} elsif (/^C/) {
			push @conflicts, substr($_, 2);
		}
	}

	print "\nAdded files\n";
        if (scalar(@added) ne "0") {
	print scalar(@added);
	print " -->Added file(s)\n";
          foreach $added (@added) {
             printf ("%5s", "$added");
             }
        } else {
          print "--> No added files\n";
        }


	print "\nModified files\n";
        if (scalar(@modified) ne "0") {
	print scalar(@modified);
	print " -->Modified file(s)\n";
          foreach $modified (@modified) { 
             printf ("%5s", "$modified");
             }      
        } else {
          print "--> No modified files\n";
        }


	print "\nRemoved files\n";
        if (scalar(@removed) ne "0") {
	print scalar(@removed);
	print " -->Removed file(s)\n";
          foreach $removed (@removed) { 
             printf ("%5s", "$removed");
             }      
        } else {
          print "--> No removed files\n";
        }


	print "\nConflicting files\n";
	if (scalar(@conflicts) ne "0") {
	print scalar(@conflicts);
	print " -->Conflicting file(s)\n";
          foreach $conflicts (@conflicts) { 
             printf ("%5s", "$conflicts");
             }      
	} else {
	  print "--> No merge conflicts\n";
	}


	close (STDOUT);
	close (STDERR);
}

sub makeMergescript {

	@mod_list = (@added, @modified, @conflicts);
	@br_tag_list = (@added, @modified, @conflicts);
	
	open (STDOUT, ">$MERGE_PRG");
        open (STDERR, ">$MERGE_PRG_ERR");
	print "\#/usr/bin/sh\n";
	print "\#\n";
	print "\# $RPT_TITLE\n"; 
	print "\# Subversion script to update, checkin, tag, and houseclean \n";
	print "\# merged files from branch $BRANCH_NAME to $HEAD\n";
	print "\#\n";
	print "\# Instructions to practitioner:\n";
	print "\# Place this script in the $HEAD directory, the parent \n";
	print "\# of the module named subdirectory where the merge has \n";
	print "\# taken place and change the permissions to add execute.\n";

	print "cd $MODULE_NAME\n";
	print "svn update\n";
	print "svn ci -m\"0000000 Merged from $BRANCH_NAME to $HEAD of revision range $REV_RNG on $MERGE_DATE\"\n";
	close (STDOUT);
	close (STDERR);
}

sub notused_removetag {
        foreach $removetag (@removed) {
                print "cvs -z3 -q tag -d Mon $removetag";
                print "cvs -z3 -q tag -d Tue $removetag";
                print "cvs -z3 -q tag -d Wed $removetag";
                print "cvs -z3 -q tag -d Thu $removetag";
                print "cvs -z3 -q tag -d Fri $removetag";
                print "cvs -z3 -q tag -d Sat $removetag";
                print "cvs -z3 -q tag -d Sun $removetag";
                }

}

sub makeTagscript {

        open (STDOUT, ">$TAGBR_PRG");
        open (STDERR, ">$TAGBR_PRG_ERR");
        print "\#/usr/bin/sh\n";
        print "\#\n";
        print "\# $RPT_TITLE\n";
        print "\# CVS script to tag files which merged from $BRANCH_NAME to $HEAD on $MERGE_DATE\n";
        print "\# Place this script in the branch subdirectory and change the permissions to add execute.\n";

	print "cvs -z3 -q co -r $BRANCH_NAME $MODULE_NAME\n";
        print "cd $MODULE_NAME\n";
#	print "diff -r js_tmp ../br_sprint5/js_tmp | awk '\/iffer\/ {print \"cp \"\$3\" ..\/$HEAD\"}' >.\/diffjars.sh\n"; 
        foreach $tagged (@br_tag_list) {
	#	`if [diff $BRANCH_NAME/$MODULE_NAME/$tagged $HEAD/$MODULE_NAME/$tagged]` {
	#	print "cp $tagged $HEAD/$tagged\n";
	#	} 
                print "cvs -z3 -q tag -r$MERGE_REVIEW$BRANCH_NAME$MERGE_DATE $MERGE_TO_TAG$HEAD$MERGE_DATE $tagged";
                }
        close (STDOUT);
        close (STDERR);
}

sub checkJars {
	        chdir("$MERGE_BRANCH_LOC") || die "Couldn't change to the $MERGE_BRANCH_LOC directory";	
		`pwd`;
		$DIFF=`diff -r $MODULE_NAME ../$HEAD/$MODULE_NAME | awk '/iffer/ {print $3}'`;
		print "$DIFF\n";
}

sub cleanUp {
`cp $MERGE_RPT $MERGE_WORK`;
`cp $MERGE_ERR $MERGE_WORK`;
}

