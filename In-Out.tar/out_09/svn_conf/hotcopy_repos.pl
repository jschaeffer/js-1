#!/usr/bin/perl
#
# Program to automate the hotcopy process, retain the SVN ID at that time
#
# Author: J. Schaeffer 30 Jan 08
#
# Command execution is %>perl chk_svn.pl
#  
$SVNLOOK_CMD = "/opt/repos_tools/svnlook";
#chomp $SVNLOOK_CMD;

$SVNADMIN_CMD = "/opt/repos_tools/svnadmin";
#chomp $SVNADMIN_CMD;

$REPOS="/upp/svn/repos";
chomp $REPOS;

$E_REV=`$SVNLOOK_CMD youngest $REPOS`;
chomp $E_REV;

$BCK_NAME="repos_backup_$E_REV";

$BCK_LOC="/net/nas-server/Sites/svn";

print "$SVNADMIN_CMD hotcopy $REPOS $BCK_LOC/$BCK_NAME\n";

