#!/usr/bin/perl
#
# Program to automate the Subversion Build tagging process, using the SVN ID, BuildId
# Branch ID, etc. in creating a tag at the proper position, with the proper name and 
# making the the correct comment
#
# Author: J. Schaeffer 30 Jan 08
#
# Command execution is %>perl tag_build.pl <Build ID> <Branch ID>
#
# SVN Tag command looks like this: 
#  svn cp -m"0000000 Creating Build tag with id Build_5_4_0-03 from branch br_5_4_x at SVN ID 15713" svn://reproc.sfbay/world/branches/br_5_4_x svn://reproc.sfbay/world/tags/Build_5_4_0-03

#  
$SVNLOOK_CMD = "/opt/repos_tools/svnlook";

$SVN_CMD = "/opt/repos_tools/svn";

$REPOS= "svn://reproc.sfbay/world";
#chomp $REPOS;

$LOC_REPOS= "/upp/svn/repos";

$E_REV=`$SVNLOOK_CMD youngest $LOC_REPOS`;
chomp $E_REV;

 if ($ARGV[0]|$ARGV[1] eq '') {
        print "No Build Arguement given.  Use perl tag_build \<Build ID\> \<Branch ID\>\n";
	exit;
         } else {
        print "Creating Build tag with id $ARGV[0] from branch $ARGV[1] at SVN ID $E_REV\n\n";
	}

$BRANCH_LOC="$REPOS/branches";
$TAG_LOC="$REPOS/tags";

	print "\`$SVN_CMD cp -m\"0000000 Creating Build tag for $ARGV[0] from branch $ARGV[1] at SVN ID $E_REV in $TAG_LOC/$ARGV[0]\" $BRANCH_LOC/$ARGV[1] $TAG_LOC/$ARGV[0]\`\n";
	`$SVN_CMD cp -m"0000000 Creating Build tag for $ARGV[0] from branch $ARGV[1] at SVN ID $E_REV in $TAG_LOC/$ARGV[0]" $BRANCH_LOC/$ARGV[1] $TAG_LOC/$ARGV[0]`;

