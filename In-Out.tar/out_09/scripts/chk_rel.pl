#!/usr/bin/perl
#
# Program to automate create the change activity report for each build.
#
# Author: J. Schaeffer 30 Jan 08
#
# Command execution is %>perl chk_svn.pl
#  
# In the 'defineVars' routing below set the following for variables for activity
# SVN revision ids: 
#  $MODULE_NAME, $S_REV (Starting Revision) $E_REV (Ending Revision), 
#  $BRANCH (Branch to be evaluated)

#  Define needed routines for the merge process (by default enable them all)

	&define_vars;
	&get_changed;
	&make_report;



sub define_vars {
$SVN_CMD = "/opt/repos_tools/svnlook";
chomp $SVN_CMD;

# RE Defined variables

$MODULE_NAME="world";
$BRANCH_NAME="br_5_12_0";
#---  Branch creation revisions
#  16054 - br_5_5_0
#  16053 - br_5_x
#  17507 - br_5_6_0
#  17946 - br_5_7_0
#  17946 - br_5_x
#  18312 - br_5_9_0

$S_REV="19948";
#$E_REV="17946";
$E_REV=`$SVN_CMD youngest /upp/svn/repos`;

# END RE Defined variables

# Pre-defined variables
$REPOS="/upp/svn/repos";
#$LOG_DIR="/export/home/js215186/reports";
$LOG_DIR="/var/apache2/htdocs";
$CHG_RPT="$LOG_DIR/$BRANCH_NAME/5_12_1_changes.html";
$CHG_ACT_RPT="$LOG_DIR/$BRANCH_NAME/5_12_1_Summary.txt";
$ERR_RPT="/tmp/chg_err.log";
$RPT_TITLE="Change activity on branch $BRANCH_NAME";
# Declare variables and arrays
	@added = qw();
	@modified = qw();
	@removed = qw();
	@conflicts = qw();
	@mod_list = (@added, @modified, @conflicts);
	@br_tag_list = (@added, @modified, @conflicts);
		# If updated at parent dir. $start = (length($MODULE_NAME)+1);
		# If updated at parent dir. $checkin1 = substr($checkin, $start);	
}

sub get_changed {

`rm $CHG_RPT`;

open (STDOUT, ">$CHG_RPT");
open (STDERR, ">$ERR_RPT");

	print "<html><body>\n";
	print "<h2>$RPT_TITLE</h2>\n";	

       	print "Sequential logging of changes between branch creation revision $S_REV and $E_REV<br>\n";
	print "For summary information of these changes click <a href=5_11_0_Summary.txt>here</a><br><hr>\n";
	$TMP_EREV = $E_REV;
	$TMP_EREV++;
	while ($TMP_EREV >= $S_REV) {
		#print "<table width=100% border=1><tr><td>\n";
		#print "$TMP_EREV\n";
		$TMP_EREV_LOG = `$SVN_CMD log -r$TMP_EREV /upp/svn/repos`;
		$BUG_LNK = substr($TMP_EREV_LOG,0,7);
		#print "SVN ID: $TMP_EREV   Comment: <a href=http://bt2ws.central.sun.com/CrPrint?id=$BUG_LNK>$TMP_EREV_LOG</a>";
		#print "</td></tr></table>\n";
		$_ = `$SVN_CMD changed -r$TMP_EREV /upp/svn/repos | grep $MODULE_NAME/branches/$BRANCH_NAME`;

		#$TMP_EREV_CHGS = `$SVN_CMD changed -r$TMP_EREV /upp/svn/repos | grep $MODULE_NAME/branches/$BRANCH_NAME`;
		if (/$BRANCH_NAME/) {
			print "<table width=80% border=1><tr><td>\n";
			print "SVN ID: $TMP_EREV   Comment: <a href=http://bt2ws.central.sun.com/CrPrint?id=$BUG_LNK>$TMP_EREV_LOG</a>";
			print "</td></tr></table>\n";
			print "<pre>\n$_</pre>\n";
		}
		$TMP_EREV--;
	}
	print "</body></html>";

   close (STDOUT);

}


sub make_report {

	@added = qw();
	@modified = qw();
	@removed = qw();
	@conflicts = qw();

	`rm $CHG_ACT_RPT`;
 	
	open (STDOUT, ">>$CHG_ACT_RPT");

	open(infile, "$CHG_RPT") || die "Can't open file: $!";
	
	while(<infile>) {
		if (/^A/) {
			if (/$MODULE_NAME\/branches\/$BRANCH_NAME/) {
			push @added, substr($_, 2); 
			}
		} elsif (/^U/) {
			if (/$MODULE_NAME\/branches\/$BRANCH_NAME/) {
			push @modified, substr($_, 2);
			}
		} elsif (/^D/) {
			if (/$MODULE_NAME\/branches\/$BRANCH_NAME/) {
			push @removed, substr($_, 2);
			}
		} elsif (/^C/) {
			push @conflicts, substr($_, 2);
		}
	}

	print "\nAdded files\n";
        if (scalar(@added) ne "0") {
	print scalar(@added);
	print " -->Added file(s)\n";
          foreach $added (@added) {
             printf ("%5s", "$added");
             }
        } else {
          print "--> No added files\n";
        }


	print "\nModified files\n";
        if (scalar(@modified) ne "0") {
	print scalar(@modified);
	print " -->Modified file(s)\n";
          foreach $modified (@modified) { 
             printf ("%5s", "$modified");
             }      
        } else {
          print "--> No modified files\n";
        }


	print "\nRemoved files\n";
        if (scalar(@removed) ne "0") {
	print scalar(@removed);
	print " -->Removed file(s)\n";
          foreach $removed (@removed) { 
             printf ("%5s", "$removed");
             }      
        } else {
          print "--> No removed files\n";
        }

	close (STDOUT);
	close (STDERR);
        `chmod 777 $CHG_ACT_RPT`;
	`chmod 777 $CHG_RPT`;

}
