#!/usr/bin/perl
#
# Program to automate create the change activity report for each build.
#
# Author: J. Schaeffer 30 Jan 08
#
# Command execution is %>perl chk_svn.pl
#  
# In the 'defineVars' routing below set the following for variables for activity
# SVN revision ids: 
#  $MODULE_NAME, $S_REV (Starting Revision) $E_REV (Ending Revision), 
#  $BRANCH (Branch to be evaluated)

#  Define needed routines for the merge process (by default enable them all)

	&define_vars;
	&get_changed;
	#&make_report;



sub define_vars {
$SVN_CMD = `which svnlook`;
chomp $SVN_CMD;

# RE Defined variables

$MODULE_NAME="world";
$BRANCH_NAME="br_5_4_x";
#---  Branch creation revisions
#  15481 - br_5_3_2
#  15480 - br_5_4_x
#  15640 - Build_5_4_0-01 & Build_5_3_3-01 
#  
#
$S_REV="15479";
$E_REV=`$SVN_CMD youngest /upp/svn/repos`;

# END RE Defined variables

# Pre-defined variables
$REPOS="/upp/svn/repos";
#$LOG_DIR="/var/apache2/htdocs";
$LOG_DIR="/export/home/js215186/reports";
$CHG_RPT="$LOG_DIR/all_re_act.html";
$CHG_ACT_RPT="$LOG_DIR/Summary.txt";
$SUM_RPT="Summary.txt";
$ERR_RPT="/tmp/newchg_err.log";
$RPT_TITLE="Release Engineering activity in repository since conversion from CVS";
# Declare variables and arrays
	@added = qw();
	@modified = qw();
	@removed = qw();
	@conflicts = qw();
	@mod_list = (@added, @modified, @conflicts);
	@br_tag_list = (@added, @modified, @conflicts);
		# If updated at parent dir. $start = (length($MODULE_NAME)+1);
		# If updated at parent dir. $checkin1 = substr($checkin, $start);	
}

sub get_changed {

`rm $CHG_RPT`;

open (STDOUT, ">$CHG_RPT");
open (STDERR, ">$ERR_RPT");

	print "<html><body>\n";
	print "<h2>$RPT_TITLE</h2>\n";	

       	print "All Merge and Tagging activity in the repository for world since the CVS revision range $S_REV : $E_REV<br>\n";
	$TMP_EREV = $E_REV;
	$TMP_EREV++;
	while ($TMP_EREV >= $S_REV) {
		$TMP_EREV_LOG = `$SVN_CMD log -r$TMP_EREV /upp/svn/repos`;
		$BUG_LNK = substr($TMP_EREV_LOG,0,7);

# Check for tagging activity
		$_ = `$SVN_CMD changed -r$TMP_EREV /upp/svn/repos | grep $MODULE_NAME`;
		$files_changed = $_;
		if (/world\/tags/) {
			print "<table width=80% bgcolor=gold border=1><tr><td>\n";
			print "SVN ID: $TMP_EREV   Comment: $TMP_EREV_LOG";
			print "</td></tr></table>\n";
			print "<pre>$_</pre>\n";
		} 

		$_ = `$SVN_CMD log -r$TMP_EREV /upp/svn/repos`;
		if (/Merge/) {
# Check for merge activity
                        print "<table width=80% bgcolor=lightblue border=1><tr><td>\n";
                        print "SVN ID: $TMP_EREV   Comment: $TMP_EREV_LOG";
                        print "</td></tr></table>\n";
                        print "<pre>$files_changed</pre>\n";
                }
		$TMP_EREV--;
	}
	print "</body></html>";

   close (STDOUT);

}


sub make_report {

	@added = qw();
	@modified = qw();
	@removed = qw();
	@conflicts = qw();

	`rm $CHG_ACT_RPT`;
 	
	open (STDOUT, ">>$CHG_ACT_RPT");

	open(infile, "$CHG_RPT") || die "Can't open file: $!";
	
	while(<infile>) {
		if (/^A/) {
			if (/$MODULE_NAME/) {
			push @added, substr($_, 2); 
			}
		} elsif (/^U/) {
			if (/$MODULE_NAME/) {
			push @modified, substr($_, 2);
			}
		} elsif (/^D/) {
			if (/$MODULE_NAME/) {
			push @removed, substr($_, 2);
			}
		} elsif (/^C/) {
			push @conflicts, substr($_, 2);
		}
	}

	print "\nAdded files\n";
        if (scalar(@added) ne "0") {
	print scalar(@added);
	print " -->Added file(s)\n";
          foreach $added (@added) {
             printf ("%5s", "$added");
             }
        } else {
          print "--> No added files\n";
        }


	print "\nModified files\n";
        if (scalar(@modified) ne "0") {
	print scalar(@modified);
	print " -->Modified file(s)\n";
          foreach $modified (@modified) { 
             printf ("%5s", "$modified");
             }      
        } else {
          print "--> No modified files\n";
        }


	print "\nRemoved files\n";
        if (scalar(@removed) ne "0") {
	print scalar(@removed);
	print " -->Removed file(s)\n";
          foreach $removed (@removed) { 
             printf ("%5s", "$removed");
             }      
        } else {
          print "--> No removed files\n";
        }

	close (STDOUT);
	close (STDERR);
        `chmod 777 $CHG_ACT_RPT`;
	`chmod 777 $CHG_RPT`;

}
