#!/bin/sh
# Post actions on chk_Rel.pl

#cp /var/apache2/htdocs/br_5_12_0/5_12_1_Summary.txt .
#mv 5_12_1_Summary.txt add.txt

# To get only pushable (non application files)
more add.txt | awk '!/application/ {print | "sort -u"}' >non_app_sorted.txt

## To get a unique list of modified applicatioins for release
#more add.txt | awk -F"/" '/application/ {print $5 | "sort -u"}' >apps.txt

