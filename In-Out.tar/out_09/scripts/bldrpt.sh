#!/bin/sh
# Nightly build script for changes to /world

TAGS_DIR=svn://reproc.sfbay/world/taqs

cd /projects/world

BRANCH_ID=`svn info | awk -F"/" '/br_/ {print $(NF)}'`

START_SVN=`svn info | awk '/Revision/ {print $2}'`
#START_SVN="19858"

END_SVN=`svn info -r'HEAD' | awk '/Revision/ {print $2}'`

cd /export/home/js215186/scripts

#echo "perl autochk_Build.pl ${BRANCH_ID} ${START_SVN} ${END_SVN}"
`perl autochk_Build.pl ${BRANCH_ID} ${START_SVN} ${END_SVN}`

cd /projects/world
svn update
