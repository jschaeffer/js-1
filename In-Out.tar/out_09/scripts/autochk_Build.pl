#!/usr/bin/perl
#
# Program to automate create the change activity report for each build.
#
# Author: J. Schaeffer 30 Jan 08
#
# Command execution is %>perl chk_svn.pl
#  
# In the 'defineVars' routing below set the following for variables for activity
# SVN revision ids: 
#  $MODULE_NAME, $S_REV (Starting Revision) $E_REV (Ending Revision), 
#  $BRANCH (Branch to be evaluated)


	&define_vars;
	&get_changed;


sub define_vars {
$SVN_CMD = `which svnlook`;
chomp $SVN_CMD;

# Script provided 
# $ARGV[0] = branch
# $ARGV[1] = Starting SVN rev
# $ARGV[2] = Latest branch HEAD rev

$BRANCH_NAME="$ARGV[0]";
$S_REV="$ARGV[1]";
$E_REV="$ARGV[2]";
$MODULE_NAME="world";
$BuildID="$ARGV[1]_$ARGV[2]";

# END RE Defined variables

# Pre-defined variables
$SUM_RPT="$BuildID_Summary.txt";
$REPOS="/upp/svn/repos";
$LOG_DIR="/var/apache2/htdocs";
$CHG_RPT="$LOG_DIR/$BRANCH_NAME/$BuildID.html";
$CHG_ACT_RPT="$LOG_DIR/$BRANCH_NAME/$BuildID.txt";
$ERR_RPT="/tmp/chg_err.log";
$RPT_TITLE="Change activity on branch $BRANCH_NAME for Build $BuildID";
# Declare variables and arrays
	@added = qw();
	@modified = qw();
	@removed = qw();
	@conflicts = qw();
	@mod_list = (@added, @modified, @conflicts);
	@br_tag_list = (@added, @modified, @conflicts);
		# If updated at parent dir. $start = (length($MODULE_NAME)+1);
		# If updated at parent dir. $checkin1 = substr($checkin, $start);	
}

sub get_changed {

`rm $CHG_RPT`;

open (STDOUT, ">$CHG_RPT");
open (STDERR, ">$ERR_RPT");

	print "<html><body>\n";
	print "<h2>$RPT_TITLE</h2>\n";	

       	print "Sequential logging of changes since last build on branch revision range $S_REV : $E_REV<br>\n";
	print "For summary information of these changes click <a href=$CHG_ACT_RPT>here</a><br><hr>\n";
	$TMP_EREV = $E_REV;
	$TMP_EREV++;
	while ($TMP_EREV >= $S_REV) {
		#print "<table width=100% border=1><tr><td>\n";
		#print "$TMP_EREV\n";
		$TMP_EREV_LOG = `$SVN_CMD log -r$TMP_EREV /upp/svn/repos`;
		$BUG_LNK = substr($TMP_EREV_LOG,0,7);
		#print "SVN ID: $TMP_EREV   Comment: <a href=http://bt2ws.central.sun.com/CrPrint?id=$BUG_LNK>$TMP_EREV_LOG</a>";
		#print "</td></tr></table>\n";
		$_ = `$SVN_CMD changed -r$TMP_EREV /upp/svn/repos | grep $MODULE_NAME/branches/$BRANCH_NAME`;

		#$TMP_EREV_CHGS = `$SVN_CMD changed -r$TMP_EREV /upp/svn/repos | grep $MODULE_NAME/branches/$BRANCH_NAME`;
		if (/$BRANCH_NAME/) {
			print "<table width=80% border=1><tr><td>\n";
			print "SVN ID: $TMP_EREV   Comment: <a href=http://bt2ws.central.sun.com/CrPrint?id=$BUG_LNK>$TMP_EREV_LOG</a>";
			print "</td></tr></table>\n";
			print "<pre>$_</pre>\n";
		}
		$TMP_EREV--;
	}
	print "</body></html>";

   close (STDOUT);

}


sub make_report {

	@added = qw();
	@modified = qw();
	@removed = qw();
	@conflicts = qw();

	`rm $CHG_ACT_RPT`;
 	
	open (STDOUT, ">>$CHG_ACT_RPT");

	open(infile, "$CHG_RPT") || die "Can't open file: $!";
	
	while(<infile>) {
		if (/^A/) {
			if (/$MODULE_NAME\/branches\/$BRANCH_NAME/) {
			push @added, substr($_, 2); 
			}
		} elsif (/^U/) {
			if (/$MODULE_NAME\/branches\/$BRANCH_NAME/) {
			push @modified, substr($_, 2);
			}
		} elsif (/^D/) {
			if (/$MODULE_NAME\/branches\/$BRANCH_NAME/) {
			push @removed, substr($_, 2);
			}
		} elsif (/^C/) {
			push @conflicts, substr($_, 2);
		}
	}

	print "\nAdded files\n";
        if (scalar(@added) ne "0") {
	print scalar(@added);
	print " -->Added file(s)\n";
          foreach $added (@added) {
             printf ("%5s", "$added");
             }
        } else {
          print "--> No added files\n";
        }


	print "\nModified files\n";
        if (scalar(@modified) ne "0") {
	print scalar(@modified);
	print " -->Modified file(s)\n";
          foreach $modified (@modified) { 
             printf ("%5s", "$modified");
             }      
        } else {
          print "--> No modified files\n";
        }


	print "\nRemoved files\n";
        if (scalar(@removed) ne "0") {
	print scalar(@removed);
	print " -->Removed file(s)\n";
          foreach $removed (@removed) { 
             printf ("%5s", "$removed");
             }      
        } else {
          print "--> No removed files\n";
        }

	close (STDOUT);
	close (STDERR);
        `chmod 777 $CHG_ACT_RPT`;
	`chmod 777 $CHG_RPT`;

}
i#---  Branch creation revisions    See history at the bottom
#  15481 - br_5_3_2
#  15480 - br_5_4_x
#  15640 - Build_5_4_0-01 & Build_5_3_3-01
#  15701 - Build_5_4_0-02 & Build_5_3_3-03
#  15713 - Build_5_4_0-03
#  15744 - Build_5_4_0-04
#  15753 - Build_5_4_0-05
#  15760 - Build_5_4_0-06
#  15765 - Build_5_4_0-07
#  15770 - Build_5_4_0-08
#  15779 - Build_5_4_1-I01
#  15796 - Build_5_4_1-I02
#  15823 - Build_5_5_0-I03
#  15861 - Build_5_5_0-I04
#  15892 - Build_5_5_0-I05
#  15925 - Build_5_5_0-01
#  15953 - Build_5_5_0-02
#  15969 - Build_5_5_0-03
#  15990 - Build_5_5_0-04
#  16000 - Build_5_5_0-05
#  16018 - Build_5_5_0-06
#  16032 - Build_5_5_0-07
#  16034 - Build_5_5_0-08
#  16043 - Build_5_5_0-10
#  16083 - Build_5_5_1-01
#  16088 - Build_5_5_1-02
#  16100 - Build_5_5_1-03
#  16102 - Build_5_5_1-04
#  16118 - Build_5_5_1-05
#  16161 - Build_5_6_0-I03
#  16156 - Build_5_5_1_08
#  16156-16223 - Build_5_5_1_10 (ie; 5.5.1-01 baseline)
#  16179-16243 - Build_5_6_0-I04
#  16244-16270 - Build_5_6_0-I05
#  16275-17416 - Build_5_6_0-01
#  17417-17432 - Build_5_6_0-02
#  17433-17445 - Build_5_6_0-03
#  17446-17453 - Build_5_6_0-04
#  17454-17470 - Build_5_6_0-05
#  17471-17474 - Build_5_6_0-06
#  17475-17492 - Build_5_6_0-07
#  17493-17510 - Build_5_6_0-08
#  17531-17548 - Build_5_6_0-10
#  17549-17573 - Build_5_6_0-11
#  17574-17584 - Build_5-6_0-12
#  17585-17603 - Build_5_6_0-13
#  17604-17607 - Build_5_6_0-14
#  17608-17613 - Bulid_5_6_0-15
#  17614-17625 - Build_5_6_0-16
#  17626-17632 = Bulid_5_6_0-17
#  17633-17637 - Build_5_6_0-18
#  17507-17725 - Build_5_7_0-I01
#  17526-17776 - Build_5_7_0-I02
#  17776-17792 - Build_5_7_0-01
#  17793-17806 - Build_5_7_0-02
#  17807-17830 - Build_5_7_0-03
#  17831-17847 - Build_5_7_0-04
#  17848-17865 - Build_5_7_0-05
#  17866-17876 - Build_5-7_0-06
#  17877-17891 - Build_5_7_0-07
#  17892-17911 - Build_5_7_0-08
#  17913-17927 - Build_5_7_0-09
#  17929-17930 - Build_5_7_0-10
#  17930-17946 - Build_5_7_0-12
#  17947-17956 - Build_5_7_0-13
#  17963-17971 - Build_5_7_0-15

