#/bin/sh

# Setup the 'Bamboo system immitator' env variables
# These ensure the command line ant targets are used, .vs. calling the netbeans
# targets, project.properties, etc.

# This file can be run to set this up (after your own local modifications)
# Or you can choose to set these variables up independently

#     SDKS Tree Home
export SDKS_HOME = ./SDKS-20CI
#     Ant Home
export ANT_HOME = ./ant1.7
#     Java Home
export JAVA_HOME = ./java_1.6
#     Bamboo imitator
export bamboo.esrgsys= 1
#     Component specific naming
# ERMSERVICEWRAPPER
export ant.build.key=EMMSERVICEWRAPPER-20CI
ant clean ci_build -Dbamboo.esrgsys="1" -Dant.build.key=EMMSERVICEWRAPPER-20CI -DSDKS_HOME="(wherever you have the SDKS placed /SDKS-20CI)"

CURVEFIT/
EKBEDITOR/
EMMSERVICEWRAPPER/
ERMAPIINTERFACES/
ERMAPPLICATIONAPI/
ERMCOMMON/
ERMCOMMONDATAACCESS/
ERMCONFIGMODEL/
ERMDATAVIEWER/
ERMGUARDIAN/
ERMINTELLIGENCEENGINEAPI/
ERMINTELLIGENCEENGINEEAR/
ERMINTELLIGENCEENGINEEJB/
ERMINTELLIGENCEENGINEPROCESSORS/
ERMINTELLIGENCEENGINEWEB/
ERMJPA/
ERMRULESETMODELEJB/
ERMRUNTIME/
ERMSQL/
ERMTOOLS/
ERMUTILS/
ERMVIEWER/
ERMVIEWEREJB/
ICASDAQ/
ICASWRAPPER/
INTELLIGENCEENGINERULESETS/
MAINTENANCEMANAGER/
NETTCPSIMULATOR/
OPCDAQ/
PIM/
PREMATESTHARNESS/
RULEEDITORJPA/
RULESETMODEL/
SDKS/

ant.build.key=ERMAPPLICATIONAPI-20CI
ant.build.key=ERMCOMMON-20CI
ant.build.key=ERMCOMMONDATAACCESS-20CI
ant.build.key=ERMCONFIGMODEL-20CI
ant.build.key=ERMDATAVIEWER-20CI
ant.build.key=ERMGUARDIAN-20CI
ant.build.key=ERMINTELLIGENCEENGINEEAR-20CI
ant.build.key=ERMINTELLIGENCEENGINEEJB-20CI
ant.build.key=ERMINTELLIGENCEENGINEPROCESSORS-20CI
ant.build.key=ERMINTELLIGENCEENGINEWEB-20CI
ant.build.key=ERMJPA-20CI
ant.build.key=ERMRULESETMODELEJB-20CI
ant.build.key=ERMRUNTIME-20CI
ant.build.key=ERMSQL-20CI
ant.build.key=ERMVIEWER-20CI
ant.build.key=ERMVIEWEREJB-20CI
ant.build.key=MAINTENANCEMANAGER-20CI
ant.build.key=OPCDAQ-20CI
