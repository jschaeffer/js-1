#!/bin/bash 

echo "This is the output of test.sh"
