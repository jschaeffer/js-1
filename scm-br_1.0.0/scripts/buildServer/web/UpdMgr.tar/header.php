<table border="0" width=80%>
    <tr>
        <td><image src="images/logo.png"/></td>
        <td><h1><u>Canoe Ventures SCM Main</h1></td><td>&nbsp&nbsp&nbsp<td align=right></td>
    </tr>
</table>
<hr size="1"/>
