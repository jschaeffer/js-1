<?php

$components = array("caas-core", "ads-core", "oss_bar", "dai_amm", "dai-billing", "dai-etl-feeder", "dai-cip", "dai-cip-feedback", "dai-smsi", "dai-lincoln", "smsi-admin", "smsi-publisher", "crypt", "Dynamic-Ad-Insertion-cm", "Dynamic-Ad-Insertion-engine", "ops-dt", "ops-dt-domain", "ops-dce-safi-reporting-agent", "ops-dce-scte-cfa-reporting-agent", "ops-dce-metadata-agent", "caas-admin", "Pgmr-Cpgn-Int", "dai-smsi-relay");

$envs = array(devint, scrum1, scrum2, scrum3, performance, lab2lab, production);


?>

