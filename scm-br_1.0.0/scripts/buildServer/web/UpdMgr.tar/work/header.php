<table border="0">
    <tr>
        <td><image src="images/logo.png"/></td>
        <td align=left><h1>Environment Configurations and Update Manager</h1></td>
   </tr>
</table>
What does the Update Manager do?<br>
<ul class="popup"><li>(Hover here)<div><object width="653" height="2400"><embed src="images/updmgr_feat.png" type="img" width="653" height="240"</embed></object></div> </li> </ul>
<hr size="1"/>
