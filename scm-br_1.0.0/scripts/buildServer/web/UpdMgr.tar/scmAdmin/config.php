<?php include '../config.php'; ?>

<?php

#$LOG_LEVEL="DEBUG";

$NEXT_PROMOTION_LEVEL="qa";

//$PROJECT="ksSchip";

$ENV_TYPE="test";

?>

<?php include '../utilFunctions.php'; ?>
