<? include 'config.php'; ?>
<head>
    <title>Vida SCM promotion page</title>
    <link rel="stylesheet" type="text/css" href="../buildServer.css" />
</head>
<body>
<? include 'header.php'; ?>
<? include '../promoteRelease.php'; ?>
<? include 'footer.php'; ?>
</body>
</html>
