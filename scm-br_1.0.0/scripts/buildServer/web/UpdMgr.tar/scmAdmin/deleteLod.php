<?php include 'config.php'; ?>
<head>
    <title>Canoe SCM Jenkins Jobs Delete Page</title>
    <link rel="stylesheet" type="text/css" href="../buildServer.css" />
</head>
<body>
<?php include 'header.php'; ?>
<?php include '../deleteLod.php'; ?>
<?php include 'footer.php'; ?>
</body>
</html>
