<?php include 'config.php'; ?>
<head>
    <title>Canoe SCM lod creation page</title>
    <link rel="stylesheet" type="text/css" href="../buildServer.css" />
</head>
<body>
<?php include 'header.php'; ?>
<?php include '../viewRel.php.php'; ?>
<?php include 'footer.php'; ?>
</body>
</html>
