<table border="0">
    <tr>
        <td><image src="../images/logo.png"/></td>
        <td><h1><strong>Canoe SCM Main Server</strong></h1></a></td>
    </tr>
    <tr>
        <td valign="bottom">
            <table>
                <tr>
                    <td><h2><a href="index.php">All available SCM tasks</a><h2></td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<hr size="1"/>
