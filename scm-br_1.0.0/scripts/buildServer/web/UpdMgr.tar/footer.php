<hr size="1"/>
<div align="center">
    &copy;&nbsp;2008-2014 Canoe Ventures All rights reserved.
</div>
