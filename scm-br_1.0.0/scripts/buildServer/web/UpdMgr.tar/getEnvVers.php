<?php
include 'envFunctions.php';
getDevInt();
?>
